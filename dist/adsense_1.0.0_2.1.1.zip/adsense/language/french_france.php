<?php

/* French language file for AdSense 1.0.0 */

$LANG_ADSENSE = array(
    'plugin_name' => 'AdSense',
    'admin_title' => 'AdSense',
    'admin_intro' => 'Gérez ici les emplacements AdSense nommés. Les réglages globaux de diffusion restent dans la configuration Geeklog.',
    'open_configuration' => 'Ouvrir la configuration AdSense',
    'autotag_description' => '[ad:EMPLACEMENT] affiche un emplacement AdSense nommé.',
    'documentation_title' => 'Bien démarrer avec Google AdSense',
    'documentation_intro' => 'Pour utiliser ce plugin, vous devez d’abord disposer d’un compte Google AdSense approuvé et avoir ajouté votre site dans AdSense.',
    'documentation_steps' => array(
        'Créez votre compte Google AdSense, ou connectez-vous à votre compte existant, puis ajoutez ce site.',
        'Attendez la validation du site par Google lorsqu’une vérification est demandée.',
        'Dans AdSense, récupérez votre ID éditeur (par exemple ca-pub-1234567890123456) et saisissez-le dans la configuration AdSense de Geeklog.',
        'Choisissez les annonces automatiques si vous souhaitez laisser Google gérer les emplacements, ou créez des blocs d’annonces dans AdSense pour utiliser des emplacements manuels.',
        'Pour chaque bloc manuel, copiez son slot ID numérique et créez ci-dessous un emplacement nommé. Insérez ensuite cet emplacement dans le contenu avec [ad:EMPLACEMENT].',
        'Contrôlez le diagnostic ads.txt sur cette page et ajoutez, si nécessaire, la ligne Google indiquée dans le fichier ads.txt situé à la racine du site.'
    ),
    'documentation_signup' => 'Créer ou ouvrir votre compte AdSense',
    'documentation_signup_url' => 'https://adsense.google.com/start/',
    'documentation_note' => 'Ce plugin configure AdSense dans Geeklog. La validation du compte et du site, les blocs d’annonces, les paiements et la majorité des réglages des annonces automatiques restent gérés dans Google AdSense.',
    'placements_title' => 'Emplacements nommés',
    'placements_help' => 'Créez des noms d’emplacement stables côté Geeklog et associez-les aux identifiants de blocs AdSense. Le contenu doit référencer le nom de l’emplacement, jamais le slot ID.',
    'placement_name' => 'Nom de l’emplacement',
    'slot_id' => 'Slot ID AdSense',
    'format' => 'Format',
    'responsive' => 'Responsive',
    'enabled' => 'Activé',
    'actions' => 'Actions',
    'save' => 'Enregistrer',
    'add' => 'Ajouter un emplacement',
    'delete' => 'Supprimer',
    'confirm_delete' => 'Supprimer cet emplacement AdSense ?',
    'placement_saved' => 'L’emplacement AdSense a été enregistré.',
    'placement_save_failed' => 'Impossible d’enregistrer l’emplacement. Vérifiez son nom, le slot ID et les doublons.',
    'placement_deleted' => 'L’emplacement AdSense a été supprimé.',
    'placement_delete_failed' => 'Impossible de supprimer l’emplacement AdSense.',
    'invalid_token' => 'La requête n’a pas pu être validée. Rechargez la page et réessayez.',
    'format_auto' => 'Automatique',
    'format_rectangle' => 'Rectangle',
    'format_horizontal' => 'Horizontal',
    'format_vertical' => 'Vertical',
    'legacy_title' => 'Compatibilité avec les autotags historiques',
    'legacy_help' => 'AdSense n’expose un alias historique compatible que si les alias sont activés et qu’aucun autre plugin actif ne possède déjà ce nom d’autotag.',
    'autotag' => 'Autotag',
    'mapped_placement' => 'Emplacement associé',
    'status' => 'État',
    'owned_by_plugin' => 'Déjà fourni par le plugin actif : %s',
    'aliases_disabled' => 'Alias historiques désactivés',
    'alias_available' => 'Disponible pour AdSense',
    'alias_unavailable' => 'Indisponible',
    'external_unchanged' => 'Externe — jamais repris par AdSense',
    'ads_txt_title' => 'Diagnostic ads.txt',
    'ads_txt_help' => 'Contrôle en lecture seule du fichier ads.txt attendu à la racine du site actif. Le plugin ne modifie pas automatiquement ce fichier.',
    'ads_txt_url' => 'URL attendue',
    'ads_txt_path' => 'Chemin local',
    'ads_txt_expected' => 'Ligne Google attendue',
    'ads_txt_publisher_invalid' => 'Un ID éditeur AdSense valide est nécessaire avant de contrôler ads.txt.',
    'ads_txt_missing' => 'Aucun fichier ads.txt n’a été trouvé à la racine du site actif.',
    'ads_txt_unreadable' => 'Le fichier ads.txt existe mais PHP ne peut pas le lire.',
    'ads_txt_line_missing' => 'ads.txt est lisible, mais la ligne correspondant à l’éditeur configuré est absente.',
    'ads_txt_ok' => 'ads.txt contient bien la ligne Google correspondant à l’éditeur configuré.',
    'usage_title' => 'Utilisation',
    'tooltip_enabled' => 'Interrupteur général de toute diffusion AdSense générée par ce plugin.',
    'tooltip_serving_mode' => 'Désactivé coupe toute diffusion. Annonces automatiques charge uniquement le script Google. Manuel affiche les emplacements nommés. Hybride combine les deux.',
    'tooltip_publisher_id' => 'Identifiant éditeur Google AdSense au format ca-pub-1234567890123456.',
    'tooltip_debug_mode' => 'Pour les administrateurs AdSense, remplace les annonces manuelles par des repères afin de contrôler les emplacements sans afficher de publicité réelle.',
    'tooltip_legacy_aliases' => 'Expose les noms d’autotags historiques compatibles uniquement si aucun autre plugin actif ne les possède déjà.',
    'tooltip_legacy_adsense_placement' => 'Emplacement nommé utilisé pour l’ancien alias adsense lorsqu’il est disponible.',
    'tooltip_legacy_inarticle_placement' => 'Emplacement nommé utilisé pour l’ancien alias inarticle lorsqu’il est disponible.',
    'tooltip_legacy_infeed_placement' => 'Emplacement nommé utilisé pour l’ancien alias infeed lorsqu’il est disponible.',
    'tooltip_legacy_leaderboard_placement' => 'Emplacement nommé utilisé pour l’ancien alias leaderboard lorsqu’il est disponible.',
    'usage_help' => 'Exemple : créez un emplacement article-middle, puis utilisez [ad:article-middle] dans un contenu Geeklog compatible.'
);

$LANG_configsections['adsense'] = array(
    'label' => 'AdSense',
    'title' => 'Configuration AdSense'
);

$LANG_confignames['adsense'] = array(
    'enabled' => 'Activer la diffusion AdSense ?',
    'serving_mode' => 'Mode de diffusion',
    'publisher_id' => 'ID éditeur',
    'debug_mode' => 'Prévisualisation des emplacements pour les administrateurs ?',
    'legacy_aliases' => 'Activer les alias compatibles des anciens autotags ?',
    'legacy_adsense_placement' => 'Emplacement associé à [adsense]',
    'legacy_inarticle_placement' => 'Emplacement associé à [inarticle]',
    'legacy_infeed_placement' => 'Emplacement associé à [infeed]',
    'legacy_leaderboard_placement' => 'Emplacement associé à [leaderboard]'
);

$LANG_configsubgroups['adsense'] = array(
    'sg_main' => 'Paramètres principaux'
);

$LANG_tab['adsense'] = array(
    'tab_main' => 'Principal'
);

$LANG_fs['adsense'] = array(
    'fs_main' => 'Diffusion des annonces',
    'fs_legacy' => 'Autotags historiques'
);

$LANG_configselects['adsense'] = array(
    0 => array(
        'Activé' => 1,
        'Désactivé' => 0
    ),
    1 => array(
        'Désactivé' => 'disabled',
        'Annonces automatiques' => 'auto',
        'Emplacements manuels' => 'manual',
        'Hybride (annonces automatiques + emplacements manuels)' => 'hybrid'
    )
);

$PLG_adsense_MESSAGE3001 = 'Mise à niveau du plugin non prise en charge.';
$PLG_adsense_MESSAGE3002 = 'Cette version de Geeklog ou de PHP n’est pas prise en charge.';
